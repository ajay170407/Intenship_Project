# Improved AI-Powered Registration Assistant

## Folder structure
Registration_Assistant_Improved/
├── app.py
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js

## Run on Windows PowerShell

1. Open PowerShell in this folder.
2. Optional: create a virtual environment:
   python -m venv venv
   .\venv\Scripts\Activate.ps1
3. Install Flask:
   pip install -r requirements.txt
4. Start the app:
   py app.py
5. Open:
   http://127.0.0.1:5000

The app creates registrations.db automatically.

Note: The eligibility rules and course fees are demo values. Replace them with your institution's official rules before using this for real admissions.

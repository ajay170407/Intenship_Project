const $ = (id) => document.getElementById(id);

function showMessage(element, message, type) {
    element.textContent = message;
    element.className = `message ${type}`;
}

function syncEligibilityFields() {
    $("check_percentage").value = $("percentage").value;
    $("check_mathematics").value = $("mathematics").value || "no";
    $("check_course").value = $("course_id").value;
}

$("course_id").addEventListener("change", syncEligibilityFields);
$("percentage").addEventListener("input", syncEligibilityFields);
$("mathematics").addEventListener("change", syncEligibilityFields);

async function checkEligibility() {
    const percentage = $("check_percentage").value;
    const mathematics = $("check_mathematics").value;
    const course_id = $("check_course").value;
    const resultBox = $("eligibilityResult");

    if (!percentage || !course_id) {
        resultBox.className = "eligibility-result not-eligible";
        resultBox.innerHTML = `
            <div class="result-icon">!</div>
            <div><strong>Missing information</strong><p>Enter your percentage and select a course.</p></div>
        `;
        return;
    }

    resultBox.className = "eligibility-result";
    resultBox.innerHTML = `
        <div class="result-icon">…</div>
        <div><strong>Checking...</strong><p>Please wait while we verify the sample eligibility rules.</p></div>
    `;

    try {
        const response = await fetch("/api/eligibility", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ percentage, mathematics, course_id })
        });

        const data = await response.json();

        if (!data.success) throw new Error(data.message);

        if (data.eligible) {
            resultBox.className = "eligibility-result eligible";
            resultBox.innerHTML = `
                <div class="result-icon">✓</div>
                <div>
                    <strong>Eligible</strong>
                    <p>${escapeHtml(data.message)} You can continue with registration.</p>
                </div>
            `;
        } else {
            resultBox.className = "eligibility-result not-eligible";
            const reasons = data.reasons.map(reason => escapeHtml(reason)).join(" ");
            resultBox.innerHTML = `
                <div class="result-icon">!</div>
                <div>
                    <strong>Not eligible under the demo rules</strong>
                    <p>${reasons}</p>
                </div>
            `;
        }
    } catch (error) {
        resultBox.className = "eligibility-result not-eligible";
        resultBox.innerHTML = `
            <div class="result-icon">!</div>
            <div><strong>Unable to check</strong><p>${escapeHtml(error.message)}</p></div>
        `;
    }
}

$("registrationForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const messageBox = $("registrationMessage");

    const payload = {
        full_name: $("full_name").value,
        email: $("email").value,
        phone: $("phone").value,
        dob: $("dob").value,
        qualification: $("qualification").value,
        percentage: $("percentage").value,
        mathematics: $("mathematics").value,
        course_id: $("course_id").value,
        address: $("address").value
    };

    if (!$("declaration").checked) {
        showMessage(messageBox, "Please confirm the declaration before submitting.", "error");
        return;
    }

    messageBox.className = "message";
    messageBox.textContent = "Submitting your registration...";

    try {
        const response = await fetch("/api/register", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            const reasons = data.reasons ? " " + data.reasons.join(" ") : "";
            throw new Error((data.message || "Registration failed.") + reasons);
        }

        showMessage(
            messageBox,
            `✓ ${data.message} Application No: ${data.application_no} | Course: ${data.course}`,
            "success"
        );

        showToast(`Application ${data.application_no} created successfully`);
        window.scrollTo({top: document.querySelector("#registration").offsetTop - 80, behavior: "smooth"});
    } catch (error) {
        showMessage(messageBox, error.message, "error");
    }
});

function selectCourse(courseId) {
    $("course_id").value = courseId;
    $("check_course").value = courseId;
    document.querySelector("#registration").scrollIntoView({behavior: "smooth"});
    showToast("Course selected. Complete your registration details.");
}

function openChat() {
    $("chatModal").classList.remove("hidden");
    $("chatInput").focus();
}

function closeChat() {
    $("chatModal").classList.add("hidden");
}

$("chatModal").addEventListener("click", (event) => {
    if (event.target === $("chatModal")) closeChat();
});

function addChatMessage(text, sender) {
    const container = $("chatMessages");
    const wrapper = document.createElement("div");
    wrapper.className = `chat-message ${sender}`;

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    wrapper.appendChild(bubble);
    container.appendChild(wrapper);
    container.scrollTop = container.scrollHeight;
}

async function sendChat(message) {
    const trimmed = message.trim();
    if (!trimmed) return;

    addChatMessage(trimmed, "user");

    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({message: trimmed})
        });

        const data = await response.json();
        addChatMessage(data.reply || "Sorry, I could not answer that.", "bot");
    } catch (error) {
        addChatMessage("The assistant is temporarily unavailable. Please try again.", "bot");
    }
}

$("chatForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const input = $("chatInput");
    const value = input.value;
    input.value = "";
    sendChat(value);
});

function sendQuick(message) {
    sendChat(message);
}

function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

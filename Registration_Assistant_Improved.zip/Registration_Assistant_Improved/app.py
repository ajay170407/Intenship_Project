from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
DB_PATH = Path(__file__).with_name("registrations.db")

COURSES = [
    {
        "id": "BCA",
        "name": "BCA - Bachelor of Computer Applications",
        "duration": "3 Years",
        "eligibility": "12th pass; Mathematics/Computer Science preferred",
        "min_percentage": 50,
        "category": "Computer Science",
        "fee": "₹45,000/year",
    },
    {
        "id": "BSC-CS",
        "name": "B.Sc. Computer Science",
        "duration": "3 Years",
        "eligibility": "12th pass with Mathematics",
        "min_percentage": 55,
        "category": "Computer Science",
        "fee": "₹40,000/year",
    },
    {
        "id": "BBA",
        "name": "BBA - Bachelor of Business Administration",
        "duration": "3 Years",
        "eligibility": "12th pass from a recognized board",
        "min_percentage": 50,
        "category": "Management",
        "fee": "₹42,000/year",
    },
    {
        "id": "BCOM",
        "name": "B.Com - Bachelor of Commerce",
        "duration": "3 Years",
        "eligibility": "12th pass from a recognized board",
        "min_percentage": 45,
        "category": "Commerce",
        "fee": "₹35,000/year",
    },
    {
        "id": "BA-ENG",
        "name": "B.A. English",
        "duration": "3 Years",
        "eligibility": "12th pass from a recognized board",
        "min_percentage": 45,
        "category": "Arts",
        "fee": "₹30,000/year",
    },
]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_no TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            dob TEXT NOT NULL,
            qualification TEXT NOT NULL,
            percentage REAL NOT NULL,
            mathematics TEXT NOT NULL,
            course_id TEXT NOT NULL,
            address TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def find_course(course_id):
    return next((course for course in COURSES if course["id"] == course_id), None)


def check_eligibility(percentage, mathematics, course_id):
    course = find_course(course_id)

    if not course:
        return {
            "eligible": False,
            "message": "Please select a valid course.",
            "reasons": ["The selected course was not found."]
        }

    reasons = []

    if percentage < course["min_percentage"]:
        reasons.append(
            f"Minimum required percentage is {course['min_percentage']}%, "
            f"but your percentage is {percentage:.1f}%."
        )

    if course_id == "BSC-CS" and mathematics.lower() != "yes":
        reasons.append("B.Sc. Computer Science requires Mathematics in the qualifying examination.")

    eligible = not reasons

    return {
        "eligible": eligible,
        "message": (
            f"You appear eligible for {course['name']}."
            if eligible
            else f"You do not currently meet all requirements for {course['name']}."
        ),
        "reasons": reasons,
        "course": course
    }


@app.route("/")
def home():
    return render_template("index.html", courses=COURSES)


@app.get("/api/courses")
def courses():
    return jsonify({"success": True, "courses": COURSES})


@app.post("/api/eligibility")
def eligibility():
    data = request.get_json(silent=True) or {}

    try:
        percentage = float(data.get("percentage", 0))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Enter a valid percentage."}), 400

    mathematics = str(data.get("mathematics", "no"))
    course_id = str(data.get("course_id", ""))

    if not 0 <= percentage <= 100:
        return jsonify({"success": False, "message": "Percentage must be between 0 and 100."}), 400

    result = check_eligibility(percentage, mathematics, course_id)
    return jsonify({"success": True, **result})


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}

    required = [
        "full_name", "email", "phone", "dob", "qualification",
        "percentage", "mathematics", "course_id", "address"
    ]

    missing = [field for field in required if not str(data.get(field, "")).strip()]
    if missing:
        return jsonify({
            "success": False,
            "message": "Please complete all required fields.",
            "missing": missing
        }), 400

    try:
        percentage = float(data["percentage"])
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Enter a valid percentage."}), 400

    if not 0 <= percentage <= 100:
        return jsonify({"success": False, "message": "Percentage must be between 0 and 100."}), 400

    course_id = str(data["course_id"])
    result = check_eligibility(percentage, str(data["mathematics"]), course_id)

    if not result["eligible"]:
        return jsonify({
            "success": False,
            "message": "Registration cannot be submitted because the eligibility check failed.",
            "reasons": result["reasons"]
        }), 400

    application_no = f"REG{datetime.now().strftime('%Y%m%d%H%M%S')}{datetime.now().microsecond // 1000:03d}"

    conn = get_db()
    try:
        conn.execute(
            """
            INSERT INTO registrations
            (application_no, full_name, email, phone, dob, qualification,
             percentage, mathematics, course_id, address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                application_no,
                str(data["full_name"]).strip(),
                str(data["email"]).strip(),
                str(data["phone"]).strip(),
                str(data["dob"]),
                str(data["qualification"]).strip(),
                percentage,
                str(data["mathematics"]),
                course_id,
                str(data["address"]).strip(),
                datetime.now().isoformat(timespec="seconds")
            )
        )
        conn.commit()
    except sqlite3.IntegrityError:
        application_no = f"REG{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        conn.execute(
            """
            INSERT INTO registrations
            (application_no, full_name, email, phone, dob, qualification,
             percentage, mathematics, course_id, address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                application_no,
                str(data["full_name"]).strip(),
                str(data["email"]).strip(),
                str(data["phone"]).strip(),
                str(data["dob"]),
                str(data["qualification"]).strip(),
                percentage,
                str(data["mathematics"]),
                course_id,
                str(data["address"]).strip(),
                datetime.now().isoformat(timespec="seconds")
            )
        )
        conn.commit()
    finally:
        conn.close()

    return jsonify({
        "success": True,
        "message": "Registration submitted successfully!",
        "application_no": application_no,
        "course": result["course"]["name"]
    })


@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip().lower()

    if not message:
        return jsonify({"success": False, "reply": "Please type a question."}), 400

    if any(word in message for word in ["hello", "hi", "hey"]):
        reply = (
            "Hello! 👋 I’m your Registration Assistant. "
            "I can help with course selection, eligibility, registration, fees, and the registration process."
        )
    elif "eligib" in message or "eligible" in message:
        reply = (
            "To check eligibility, enter your qualifying-exam percentage, Mathematics status, "
            "and preferred course in the Eligibility Checker."
        )
    elif "course" in message or "program" in message:
        names = ", ".join(course["id"] for course in COURSES)
        reply = f"We currently have these programs: {names}. Use the Course Catalog to compare them."
    elif "fee" in message or "fees" in message or "cost" in message:
        reply = "Approximate annual fees range from ₹30,000 to ₹45,000 depending on the course. Check the Course Catalog for details."
    elif "register" in message or "registration" in message or "apply" in message:
        reply = (
            "Registration is simple: complete your personal details, choose a course, "
            "run the eligibility check, and click Submit Registration."
        )
    elif "document" in message or "documents" in message:
        reply = (
            "Commonly required documents include your qualifying-exam marksheet/certificate, "
            "ID proof, passport-size photo, and other documents requested by your institution."
        )
    elif "bca" in message:
        reply = "BCA is a 3-year Computer Science program. The sample eligibility rule in this demo is a minimum of 50%."
    elif "b.sc" in message or "bsc" in message:
        reply = "B.Sc. Computer Science is a 3-year program. This demo requires 55% and Mathematics."
    elif "bba" in message:
        reply = "BBA is a 3-year Management program. The sample eligibility rule in this demo is a minimum of 50%."
    elif "b.com" in message or "bcom" in message:
        reply = "B.Com is a 3-year Commerce program. The sample eligibility rule in this demo is a minimum of 45%."
    elif "contact" in message or "help" in message:
        reply = "For institutional questions not covered here, contact your college/university admissions office."
    else:
        reply = (
            "I can help with courses, eligibility, fees, documents, or registration. "
            "Try asking: “Am I eligible for BCA?” or “What courses are available?”"
        )

    return jsonify({"success": True, "reply": reply})


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Registration Assistant"})


if __name__ == "__main__":
    init_db()
    print("=" * 64)
    print("AI-POWERED REGISTRATION ASSISTANT")
    print("=" * 64)
    print("Server: http://127.0.0.1:5000")
    print("Database: registrations.db")
    print("=" * 64)
    app.run(host="127.0.0.1", port=5000, debug=True)
